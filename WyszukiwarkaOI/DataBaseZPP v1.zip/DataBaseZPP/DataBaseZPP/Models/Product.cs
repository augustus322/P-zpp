﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database.Models
{
    internal class Product
    {
        public int Id { get; set; } //primary key
        public string Name { get; set; } = null!; //nazwa produktu - nie chcemy żeby była null
        public string? Description { get; set; } //opis - może być null
        public decimal Price { get; set; }  //cena
        public string Category { get; set; } = null!; //kategoria - nie chcemy żeby była null
        public DateTime DateAdded { get; set; } //czas dodania
    }
}
