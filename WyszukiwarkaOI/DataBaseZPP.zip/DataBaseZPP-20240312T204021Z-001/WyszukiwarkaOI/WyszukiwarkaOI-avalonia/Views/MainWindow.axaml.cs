using Avalonia.Controls;

namespace WyszukiwarkaOI_avalonia.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}