﻿using ReactiveUI;

namespace ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
