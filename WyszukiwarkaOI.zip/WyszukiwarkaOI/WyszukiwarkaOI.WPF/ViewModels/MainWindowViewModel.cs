﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace WyszukiwarkaOI.WPF.ViewModels;
public class MainWindowViewModel : ObservableObject
{

}
