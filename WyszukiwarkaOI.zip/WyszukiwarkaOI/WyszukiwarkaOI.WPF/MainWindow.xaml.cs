﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WyszukiwarkaOI.EntityFramework.Models;
using WyszukiwarkaOI_webScraper;

namespace WyszukiwarkaOI.WPF;
/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
	public MainWindow()
	{
		InitializeComponent();
	}

    private async void Button_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            /* string searchText = wyszukiwarka.Text; */
            /* WebScraper _webScraper = new WebScraper(); */

            /* var (html, isSuccess) = await _webScraper.GetWebsiteHtmlAsync("https://www.okazje.info.pl/search/?q=" + searchText); */

            /* if (!isSuccess) */
            /* { */
            /*     MessageBox.Show("Wystąpił problem podczas pobierania danych z serwera."); */
            /*     return; */
            /* } */

            /* var (elements, success) = await _webScraper.GetChildrenOfGivenElementAsync(".klasa-elementu", html); */

            /* if (!success) */
            /* { */
            /*     MessageBox.Show("Wystąpił problem podczas przetwarzania HTML."); */
            /*     return; */
            /* } */

            /* var (elementsInfo, successParsing) = _webScraper.GetElementsInfo(elements); */

            /* if (!successParsing) */
            /* { */
            /*     MessageBox.Show("Wystąpił problem podczas parsowania danych."); */
            /*     return; */
            /* } */

            List<Product> elementsInfo = new List<Product> {
            new Product("Cośtam", "Cośtam description", 21.37m, "Allegro", "allegro.pl/123"),
            new Product("Cośtam2", "Cośtam description", 21.37m, "Allegro", "allegro.pl/123"),
            new Product("Cośtam3", "Cośtam description", 21.37m, "Allegro", "allegro.pl/123"),
        };

        // Sortowanie danych po cenie rosnąco
        elementsInfo = elementsInfo.OrderBy(product => product.Price).ToList();

            // Przypisz posortowane dane do DataGrid
            searchResultsDataGrid.ItemsSource = elementsInfo;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Wystąpił błąd: {ex.Message}");
        }
    }
}